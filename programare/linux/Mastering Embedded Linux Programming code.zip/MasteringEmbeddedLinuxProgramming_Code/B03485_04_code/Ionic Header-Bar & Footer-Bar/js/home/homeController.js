var module = angular.module('BookStore.Controllers',[]);

HomeController.$inject = ['$scope'];

module.controller('HomeController',HomeController);

function HomeController($scope) {

}

